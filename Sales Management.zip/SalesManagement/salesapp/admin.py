from django.contrib import admin

from salesapp.models import Student

# Register your models here.
admin.site.register(Student)
